#  LINK ASSETS REFERENCE

1. BaksoHome, BaksoImage : https://www.masakapahariini.com/resep/resep-mie-bakso/
2. BoiledEgg : <a href="https://www.flaticon.com/free-icons/boiled-egg" title="boiled egg icons">Boiled egg icons created by surang - Flaticon</a>
3. CoconutMilk : <a href="https://www.flaticon.com/free-icons/coconut-milk" title="coconut milk icons">Coconut milk icons created by Smashicons - Flaticon</a>
4. CookedRice : <a href="https://www.flaticon.com/free-icons/rice" title="rice icons">Rice icons created by Freepik - Flaticon</a>
5. Eggs : <a href="https://www.flaticon.com/free-icons/egg" title="egg icons">Egg icons created by iconixar - Flaticon</a>
6. Fish : <a href="https://www.flaticon.com/free-icons/fish" title="fish icons">Fish icons created by Freepik - Flaticon</a>
7. Flour : <a href="https://www.flaticon.com/free-icons/flour" title="flour icons">Flour icons created by Freepik - Flaticon</a>
8. Garlic : <a href="https://www.flaticon.com/free-icons/garlic" title="garlic icons">Garlic icons created by Freepik - Flaticon</a>
9. Ginger : <a href="https://www.flaticon.com/free-icons/ginger" title="ginger icons">Ginger icons created by Freepik - Flaticon</a>
10. IndomieHome, ImdomieImage : https://food.detik.com/info-kuliner/d-5772290/indomie-masuk-dalam-daftar-10-merek-yang-paling-digemari-di-dunia
11. Lemongrass : <a href="https://www.flaticon.com/free-icons/lemongrass" title="lemongrass icons">Lemongrass icons created by dDara - Flaticon</a>
12. MartabakHome, MartabakImage : https://lifestyle.okezone.com/read/2021/08/07/298/2452497/martabak-jadi-makanan-paling-banyak-dipesan-online-selama-pandemi
13. Meat: <a href="https://www.flaticon.com/free-icons/meat" title="meat icons">Meat icons created by DinosoftLabs - Flaticon</a>
14. NasiGorengHome, NasiGorengImage : https://lifestyle.okezone.com/read/2022/08/11/298/2646282/resep-nasi-goreng-rendah-kalori-cocok-untuk-diet
15. NasiPadangHome, NasiPadangImage : https://pergikuliner.com/blog/fakta-dibalik-nasi-padang-yang-kamu-harus-tahu
16. Noodle : <a href="https://www.flaticon.com/free-icons/noodles" title="noodles icons">Noodles icons created by surang - Flaticon</a>
17. Oil : <a href="https://www.flaticon.com/free-icons/oil" title="oil icons">Oil icons created by kerismaker - Flaticon</a>
18. Onion : <a href="https://www.flaticon.com/free-icons/onion" title="onion icons">Onion icons created by dDara - Flaticon</a>
19. PempekHome, PempekImage : https://www.orami.co.id/magazine/sejarah-pempek
20. RendangHome, RendangImage : https://www.astronauts.id/blog/resep-rendang-daging-sapi-untuk-lebaran-gurih-dan-nikmat/
21. Salt : <a href="https://www.flaticon.com/free-icons/salt" title="salt icons">Salt icons created by Freepik - Flaticon</a>
22. SateHome, SateImage : https://www.dapurkobe.co.id/sate-ayam
23. SotoHome, SotoImage : https://www.sayurbox.com/blog/7-cara-membuat-soto-ayam
24. SoySauce : <a href="https://www.flaticon.com/free-icons/soy-sauce" title="soy sauce icons">Soy sauce icons created by Smashicons - Flaticon</a>
25. Sugar : <a href="https://www.flaticon.com/free-icons/sugar" title="sugar icons">Sugar icons created by Freepik - Flaticon</a>
26. Tamarind : <a href="https://www.flaticon.com/free-icons/tamarind" title="tamarind icons">Tamarind icons created by Freepik - Flaticon</a>
27. TopiocaStarch : <a href="https://www.flaticon.com/free-icons/flour" title="flour icons">Flour icons created by Smashicons - Flaticon</a>
28. Turmeric : <a href="https://www.flaticon.com/free-icons/turmeric" title="turmeric icons">Turmeric icons created by Freepik - Flaticon</a>
29. Water : <a href="https://www.flaticon.com/free-icons/water" title="water icons">Water icons created by Freepik - Flaticon</a>
30. BaksoLocation, IndomieLocation, MartabakLocation, NasiGorengLocation, NasiPadangLocation, PempekLocation, RendangLocation, SateLocation, SotoLocation : https://simplemaps.com/resources/svg-id <a href="https://www.flaticon.com/free-icons/location" title="location icons">Location icons created by apien - Flaticon</a>
31. Dango : https://www.iconfinder.com/icons/3714586/dango_dessert_food_japan_sweet_icon
32. AppIcon :   1. <a href="https://www.flaticon.com/free-icons/dish" title="dish icons">Dish icons created by Freepik - Flaticon</a>
                2. https://wiki.erepublik.com/index.php/Template:Indonesia_Map
